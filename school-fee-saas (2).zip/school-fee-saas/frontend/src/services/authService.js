// src/services/authService.js
class AuthService {
  constructor() {
    this.users = [
      { 
        id: 1, 
        name: 'Admin', 
        email: 'admin@school.com', 
        password: 'admin123', 
        role: 'admin',
        adminCode: 'SCHOOL123',
        cnicNo: '1234567890123'
      },
      { 
        id: 2, 
        name: 'Parent', 
        email: 'parent@school.com', 
        password: 'parent123', 
        role: 'parent',
        studentName: 'Test Student',
        admissionNo: 'STU2023001'
      }
    ];
  }

  async login({ email, password, role, admissionNo, adminCode }) {
    const user = this.users.find(u => 
      u.email === email && 
      u.password === password && 
      u.role === role
    );

    if (!user) throw new Error('Invalid credentials');

    // Additional role-specific validation
    if (role === 'parent' && user.admissionNo !== admissionNo) {
      throw new Error('Invalid admission number');
    }

    if (role === 'admin' && user.adminCode !== adminCode) {
      throw new Error('Invalid admin code');
    }

    return user;
  }

  async register(userData) {
    // Validate required fields
    if (userData.role === 'parent' && (!userData.studentName || !userData.admissionNo)) {
      throw new Error('Student name and admission number are required');
    }

    if (userData.role === 'admin' && (!userData.adminCode || !userData.cnicNo)) {
      throw new Error('Admin security code and CNIC are required');
    }

    // Validate admin code
    if (userData.role === 'admin' && userData.adminCode !== 'SCHOOL123') {
      throw new Error('Invalid admin security code');
    }

    const newUser = { 
      id: this.users.length + 1, 
      ...userData 
    };
    this.users.push(newUser);
    return newUser;
  }

  async getUser(id) {
    return this.users.find(u => u.id === id);
  }
}

export const authService = new AuthService();