// // // // // // // //import mysql from 'mysql2/promise';
// // // // // // // import dotenv from 'dotenv';

// // // // // // // dotenv.config();

// // // // // // // // Database configuration
// // // // // // // const dbConfig = {
// // // // // // //   host: process.env.DB_HOST || '127.0.0.1',
// // // // // // //   user: process.env.DB_USER || 'root',
// // // // // // //   password: process.env.DB_PASSWORD || '',
// // // // // // //   database: process.env.DB_NAME || 'school_fee_db',
// // // // // // //   port: process.env.DB_PORT || 3306
// // // // // // // };

// // // // // // // class PaymentService {
// // // // // // //   constructor() {
// // // // // // //     this.pool = mysql.createPool(dbConfig);
// // // // // // //   }

// // // // // // //   // Create new payment
// // // // // // //   async makePayment(paymentData) {
// // // // // // //     const connection = await this.pool.getConnection();
// // // // // // //     try {
// // // // // // //       const [result] = await connection.execute(
// // // // // // //         `INSERT INTO payments 
// // // // // // //         (user_id, parent_name, student_name, amount, status, payment_method, date, receipt_number)
// // // // // // //         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
// // // // // // //         [
// // // // // // //           paymentData.userId,
// // // // // // //           paymentData.parentName,
// // // // // // //           paymentData.studentName,
// // // // // // //           paymentData.amount,
// // // // // // //           paymentData.status || 'pending',
// // // // // // //           paymentData.method,
// // // // // // //           new Date(paymentData.date || Date.now()),
// // // // // // //           this.generateReceiptNumber()
// // // // // // //         ]
// // // // // // //       );
      
// // // // // // //       return this.getPaymentById(result.insertId);
// // // // // // //     } finally {
// // // // // // //       connection.release();
// // // // // // //     }
// // // // // // //   }

// // // // // // //   // Get payments with filters
// // // // // // //   async getPayments(userId, role) {
// // // // // // //     const connection = await this.pool.getConnection();
// // // // // // //     try {
// // // // // // //       let query = `SELECT * FROM payments`;
// // // // // // //       const params = [];

// // // // // // //       if (role !== 'admin') {
// // // // // // //         query += ` WHERE user_id = ?`;
// // // // // // //         params.push(userId);
// // // // // // //       }

// // // // // // //       const [rows] = await connection.execute(query, params);
// // // // // // //       return rows.map(row => ({
// // // // // // //         id: row.id,
// // // // // // //         userId: row.user_id,
// // // // // // //         parentName: row.parent_name,
// // // // // // //         studentName: row.student_name,
// // // // // // //         amount: row.amount,
// // // // // // //         status: row.status,
// // // // // // //         method: row.payment_method,
// // // // // // //         date: row.date.toISOString().split('T')[0],
// // // // // // //         receiptNumber: row.receipt_number
// // // // // // //       }));
// // // // // // //     } finally {
// // // // // // //       connection.release();
// // // // // // //     }
// // // // // // //   }

// // // // // // //   // Helper methods
// // // // // // //   async getPaymentById(id) {
// // // // // // //     const connection = await this.pool.getConnection();
// // // // // // //     try {
// // // // // // //       const [rows] = await connection.execute(
// // // // // // //         `SELECT * FROM payments WHERE id = ?`,
// // // // // // //         [id]
// // // // // // //       );
// // // // // // //       return rows[0];
// // // // // // //     } finally {
// // // // // // //       connection.release();
// // // // // // //     }
// // // // // // //   }

// // // // // // //   generateReceiptNumber() {
// // // // // // //     return 'REC-' + Date.now().toString(36).toUpperCase() + 
// // // // // // //       Math.floor(1000 + Math.random() * 9000);
// // // // // // //   }

// // // // // // //   // Database initialization (for first-time setup)
// // // // // // //   async initializeDatabase() {
// // // // // // //     const connection = await this.pool.getConnection();
// // // // // // //     try {
// // // // // // //       await connection.execute(`CREATE TABLE IF NOT EXISTS payments (
// // // // // // //         id INT PRIMARY KEY AUTO_INCREMENT,
// // // // // // //         user_id INT NOT NULL,
// // // // // // //         parent_name VARCHAR(100) NOT NULL,
// // // // // // //         student_name VARCHAR(100) NOT NULL,
// // // // // // //         amount DECIMAL(10,2) NOT NULL,
// // // // // // //         status ENUM('pending', 'paid', 'failed') DEFAULT 'pending',
// // // // // // //         payment_method VARCHAR(50),
// // // // // // //         date DATE NOT NULL,
// // // // // // //         receipt_number VARCHAR(20) UNIQUE,
// // // // // // //         FOREIGN KEY (user_id) REFERENCES users(id)
// // // // // // //       )`);
// // // // // // //     } finally {
// // // // // // //       connection.release();
// // // // // // //     }
// // // // // // //   }
// // // // // // // }

// // // // // // // // Initialize database on startup
// // // // // // // const paymentService = new PaymentService();
// // // // // // // paymentService.initializeDatabase();

// // // // // // // export { paymentService };
// // // // // // const API_URL = 'http://localhost:5000/api/payments';

// // // // // // export const paymentService = {
// // // // // //   makePayment: async (paymentData) => {
// // // // // //     const response = await fetch(API_URL, {
// // // // // //       method: 'POST',
// // // // // //       headers: {
// // // // // //         'Content-Type': 'application/json',
// // // // // //         'Authorization': `Bearer ${localStorage.getItem('token')}`
// // // // // //       },
// // // // // //       body: JSON.stringify(paymentData)
// // // // // //     });
    
// // // // // //     if (!response.ok) {
// // // // // //       const error = await response.json();
// // // // // //       throw new Error(error.message || 'Payment failed');
// // // // // //     }
    
// // // // // //     return await response.json();
// // // // // //   }
// // // // // // };
// // // // // const API_URL = 'http://localhost:5000/api/payments';

// // // // // export const paymentService = {
// // // // //   makePayment: async (paymentData) => {
// // // // //     const response = await fetch(API_URL, {
// // // // //       method: 'POST',
// // // // //       headers: {
// // // // //         'Content-Type': 'application/json',
// // // // //         'Authorization': `Bearer ${localStorage.getItem('token')}`
// // // // //       },
// // // // //       body: JSON.stringify(paymentData)
// // // // //     });
    
// // // // //     if (!response.ok) {
// // // // //       const error = await response.json();
// // // // //       throw new Error(error.error || 'Payment failed');
// // // // //     }
    
// // // // //     return await response.json();
// // // // //   },

// // // // //   getParentPayments: async () => {
// // // // //     const response = await fetch(API_URL, {
// // // // //       headers: {
// // // // //         'Authorization': `Bearer ${localStorage.getItem('token')}`
// // // // //       }
// // // // //     });
    
// // // // //     if (!response.ok) {
// // // // //       const error = await response.json();
// // // // //       throw new Error(error.error || 'Failed to fetch payments');
// // // // //     }
    
// // // // //     return await response.json();
// // // // //   }
// // // // // };
// // // // // frontend/src/services/paymentService.js
// // // // const API_URL = 'http://localhost:5000/api/payments';

// // // // export const paymentService = {
// // // //   makePayment: async (paymentData) => {
// // // //     const response = await fetch(API_URL, {
// // // //       method: 'POST',
// // // //       headers: {
// // // //         'Content-Type': 'application/json',
// // // //         'Authorization': `Bearer ${localStorage.getItem('token')}`
// // // //       },
// // // //       body: JSON.stringify(paymentData)
// // // //     });
    
// // // //     if (!response.ok) {
// // // //       const error = await response.json();
// // // //       throw new Error(error.message || 'Payment failed');
// // // //     }
    
// // // //     return await response.json();
// // // //   }
// // // // };
// // // const API_URL = 'http://localhost:5000/api/payments';

// // // export const paymentService = {
// // //   createPayment: async (paymentData) => {
// // //     const response = await fetch(API_URL, {
// // //       method: 'POST',
// // //       headers: {
// // //         'Content-Type': 'application/json',
// // //         'Authorization': `Bearer ${localStorage.getItem('token')}`
// // //       },
// // //       body: JSON.stringify(paymentData)
// // //     });
    
// // //     if (!response.ok) {
// // //       const error = await response.json();
// // //       throw new Error(error.error || 'Payment creation failed');
// // //     }
    
// // //     return await response.json();
// // //   },

// // //   updatePayment: async (id, paymentData) => {
// // //     const response = await fetch(`${API_URL}/${id}`, {
// // //       method: 'PUT',
// // //       headers: {
// // //         'Content-Type': 'application/json',
// // //         'Authorization': `Bearer ${localStorage.getItem('token')}`
// // //       },
// // //       body: JSON.stringify(paymentData)
// // //     });
    
// // //     if (!response.ok) {
// // //       const error = await response.json();
// // //       throw new Error(error.error || 'Payment update failed');
// // //     }
    
// // //     return await response.json();
// // //   }
// // // };
// // const API_URL = 'http://localhost:5000/api/payments';

// // export const paymentService = {
// //   createPayment: async (paymentData) => {
// //     const response = await fetch(API_URL, {
// //       method: 'POST',
// //       headers: {
// //         'Content-Type': 'application/json',
// //         'Authorization': `Bearer ${localStorage.getItem('token')}`
// //       },
// //       body: JSON.stringify(paymentData)
// //     });
    
// //     if (!response.ok) {
// //       const error = await response.json();
// //       throw new Error(error.message || 'Payment creation failed');
// //     }
    
// //     return await response.json();
// //   },

// //   updatePayment: async (id, paymentData) => {
// //     const response = await fetch(`${API_URL}/${id}`, {
// //       method: 'PUT',
// //       headers: {
// //         'Content-Type': 'application/json',
// //         'Authorization': `Bearer ${localStorage.getItem('token')}`
// //       },
// //       body: JSON.stringify(paymentData)
// //     });
    
// //     if (!response.ok) {
// //       const error = await response.json();
// //       throw new Error(error.message || 'Payment update failed');
// //     }
    
// //     return await response.json();
// //   },

// //   getParentPayments: async (parentId) => {
// //     const response = await fetch(`${API_URL}/parent/${parentId}`, {
// //       headers: {
// //         'Authorization': `Bearer ${localStorage.getItem('token')}`
// //       }
// //     });
    
// //     if (!response.ok) {
// //       throw new Error('Failed to fetch payments');
// //     }
    
// //     return await response.json();
// //   },

// //   getPaymentStats: async () => {
// //     const response = await fetch(`${API_URL}/stats`, {
// //       headers: {
// //         'Authorization': `Bearer ${localStorage.getItem('token')}`
// //       }
// //     });
    
// //     if (!response.ok) {
// //       throw new Error('Failed to fetch payment stats');
// //     }
    
// //     return await response.json();
// //   }
// // };
// const API_URL = 'http://localhost:5000/api/payments';

// export const paymentService = {
//   createPayment: async (paymentData) => {
//     const response = await fetch(API_URL, {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json',
//         'Authorization': `Bearer ${localStorage.getItem('token')}`
//       },
//       body: JSON.stringify(paymentData)
//     });
    
//     if (!response.ok) {
//       const error = await response.json();
//       throw new Error(error.message || 'Payment creation failed');
//     }
    
//     return await response.json();
//   },

//   updatePayment: async (id, paymentData) => {
//     const response = await fetch(`${API_URL}/${id}`, {
//       method: 'PUT',
//       headers: {
//         'Content-Type': 'application/json',
//         'Authorization': `Bearer ${localStorage.getItem('token')}`
//       },
//       body: JSON.stringify(paymentData)
//     });
    
//     if (!response.ok) {
//       const error = await response.json();
//       throw new Error(error.message || 'Payment update failed');
//     }
    
//     return await response.json();
//   },

//   getParentPayments: async (parentId) => {
//     const response = await fetch(`${API_URL}/parent/${parentId}`, {
//       headers: {
//         'Authorization': `Bearer ${localStorage.getItem('token')}`
//       }
//     });
    
//     if (!response.ok) {
//       throw new Error('Failed to fetch payments');
//     }
    
//     const data = await response.json();
//     return Array.isArray(data) ? data : [];
//   },

//   getPaymentStats: async () => {
//     const response = await fetch(`${API_URL}/stats`, {
//       headers: {
//         'Authorization': `Bearer ${localStorage.getItem('token')}`
//       }
//     });
    
//     if (!response.ok) {
//       throw new Error('Failed to fetch payment stats');
//     }
    
//     return await response.json();
//   }
// };
// const API_URL = 'http://localhost:5000/api/payments';

// export const paymentService = {
//   createPayment: async (paymentData) => {
//     const response = await fetch(API_URL, {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json',
//         'Authorization': `Bearer ${localStorage.getItem('token')}`
//       },
//       body: JSON.stringify(paymentData)
//     });
    
//     if (!response.ok) {
//       const error = await response.json();
//       throw new Error(error.error || 'Payment creation failed');
//     }
    
//     return await response.json();
//   },

//   getParentPayments: async (parentId) => {
//     const response = await fetch(`${API_URL}/parent/${parentId}`, {
//       headers: {
//         'Authorization': `Bearer ${localStorage.getItem('token')}`
//       }
//     });
    
//     if (!response.ok) {
//       throw new Error('Failed to fetch payments');
//     }
    
//     return await response.json();
//   },

//   getPaymentStats: async () => {
//     const response = await fetch(`${API_URL}/stats`, {
//       headers: {
//         'Authorization': `Bearer ${localStorage.getItem('token')}`
//       }
//     });
    
//     if (!response.ok) {
//       throw new Error('Failed to fetch payment stats');
//     }
    
//     return await response.json();
//   }
// };
// frontend/src/services/paymentService.js
import { v4 as uuidv4 } from 'uuid';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

class PaymentService {
  async createPayment(paymentData) {
    const idempotencyKey = uuidv4();
    
    try {
      const response = await fetch(`${API_URL}/payments`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Idempotency-Key': idempotencyKey
        },
        body: JSON.stringify(paymentData)
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Payment failed');
      }

      return await response.json();
    } catch (error) {
      console.error('Payment Error:', error);
      throw error;
    }
  }

  async getPayments(parentId) {
    try {
      const response = await fetch(`${API_URL}/payments/parent/${parentId}`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (!response.ok) throw new Error('Failed to fetch payments');
      return await response.json();
    } catch (error) {
      console.error('Get Payments Error:', error);
      throw error;
    }
  }

  async getPaymentStatus(paymentId) {
    try {
      const response = await fetch(`${API_URL}/payments/${paymentId}/status`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      
      if (!response.ok) throw new Error('Failed to get status');
      return await response.json();
    } catch (error) {
      console.error('Status Check Error:', error);
      throw error;
    }
  }
}

export default new PaymentService();