import './FilterControls.css';

const FilterControls = ({ filters, setFilters, onAddPayment }) => {
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFilters(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="filter-controls">
      <div className="search-control">
        <input
          type="text"
          name="search"
          placeholder="Search payments..."
          value={filters.search}
          onChange={handleChange}
        />
      </div>
      
      <div className="filter-group">
        <select
          name="status"
          value={filters.status}
          onChange={handleChange}
        >
          <option value="all">All Status</option>
          <option value="paid">Paid</option>
          <option value="pending">Pending</option>
          <option value="failed">Failed</option>
        </select>
        
        <input
          type="date"
          name="startDate"
          value={filters.startDate || ''}
          onChange={handleChange}
        />
        
        <input
          type="date"
          name="endDate"
          value={filters.endDate || ''}
          onChange={handleChange}
        />
      </div>
      
      <button className="add-payment-btn" onClick={onAddPayment}>
        Add Payment
      </button>
    </div>
  );
};

export default FilterControls;