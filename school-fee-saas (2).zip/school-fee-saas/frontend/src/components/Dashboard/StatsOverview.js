import './StatsOverview.css';

const StatsOverview = ({ stats }) => {
  return (
    <div className="stats-overview">
      {stats.map((stat, index) => (
        <div key={index} className="stat-card">
          <h3>{stat.title}</h3>
          <p className="stat-value" style={{ color: stat.color || 'inherit' }}>
            {stat.value}
          </p>
        </div>
      ))}
    </div>
  );
};

export default StatsOverview;