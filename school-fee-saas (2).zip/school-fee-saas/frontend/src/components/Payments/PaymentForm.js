// import { useState } from 'react';
// import { paymentService } from '../../services/paymentService';

// const PaymentForm = ({ onSuccess, onCancel }) => {
//   const [amount, setAmount] = useState('');
//   const [paymentMethod, setPaymentMethod] = useState('credit_card');
//   const [error, setError] = useState('');
//   const user = JSON.parse(localStorage.getItem('user'));

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     try {
//       const payment = await paymentService.makePayment({
//         userId: user.id,
//         parentName: user.name,
//         amount: parseFloat(amount),
//         method: paymentMethod
//       });
//       onSuccess(payment);
//     } catch (err) {
//       setError('Payment failed. Please try again.');
//     }
//   };

//   return (
//     <div className="payment-form">
//       <h3>Make Payment</h3>
//       {error && <div className="error-message">{error}</div>}
//       <form onSubmit={handleSubmit}>
//         <div className="form-group">
//           <label>Amount ($)</label>
//           <input
//             type="number"
//             value={amount}
//             onChange={(e) => setAmount(e.target.value)}
//             min="1"
//             step="0.01"
//             required
//           />
//         </div>
        
//         <div className="form-group">
//           <label>Payment Method</label>
//           <select
//             value={paymentMethod}
//             onChange={(e) => setPaymentMethod(e.target.value)}
//           >
//             <option value="credit_card">Credit Card</option>
//             <option value="bank_transfer">Bank Transfer</option>
//           </select>
//         </div>
        
//         <div className="form-actions">
//           <button type="button" onClick={onCancel}>Cancel</button>
//           <button type="submit">Submit Payment</button>
//         </div>
//       </form>
//     </div>
//   );
// };

// export default PaymentForm;
import { useState } from 'react';
import { paymentService } from '../../services/paymentService';

const PaymentForm = ({ onSuccess, onCancel, studentAdmissionNo }) => {
  const [amount, setAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('credit_card');
  const [error, setError] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const user = JSON.parse(localStorage.getItem('user'));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setIsProcessing(true);

    try {
      // Validate amount
      if (!amount || isNaN(amount) || amount <= 0) {
        throw new Error('Please enter a valid amount');
      }

      const payment = await paymentService.makePayment({
        userId: user.id,
        studentAdmissionNo, // Added from props
        amount: parseFloat(amount),
        method: paymentMethod
      });
      
      onSuccess({
        ...payment,
        parentName: user.name // Include parent name in success callback
      });
    } catch (err) {
      setError(err.message || 'Payment failed. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="payment-form">
      <h3>Make Payment for Student: {studentAdmissionNo}</h3>
      {error && <div className="error-message">{error}</div>}
      
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Amount ($)</label>
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            min="0.01"
            step="0.01"
            placeholder="0.00"
            required
          />
        </div>
        
        <div className="form-group">
          <label>Payment Method</label>
          <select
            value={paymentMethod}
            onChange={(e) => setPaymentMethod(e.target.value)}
            required
          >
            <option value="credit_card">Credit Card</option>
            <option value="bank_transfer">Bank Transfer</option>
            <option value="cash">Cash</option>
          </select>
        </div>
        
        <div className="form-actions">
          <button 
            type="button" 
            onClick={onCancel}
            disabled={isProcessing}
          >
            Cancel
          </button>
          <button 
            type="submit" 
            disabled={isProcessing || !amount}
          >
            {isProcessing ? 'Processing...' : 'Submit Payment'}
          </button>
        </div>
      </form>
    </div>
  );
};

export default PaymentForm;