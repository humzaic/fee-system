import { Link } from 'react-router-dom';
import './Home.css';

import Navbar from '../Shared/Navbar'; 
const Home = () => {
  return (
    <div className="home-page">
      {/* Navbar */}
      <Navbar />
      {/* <nav className="glass-navbar">
        <div className="navbar-brand">
          <img ssrc="../../assets/school-bg.jpg"  alt="School Logo" className="logo" />
          <span>School Fee Portal</span>
        </div>
        <div className="navbar-links">
          <Link to="/" className="nav-link">Home</Link>
          <Link to="/features" className="nav-link">Features</Link>
          <Link to="/about" className="nav-link">About</Link>
          <div className="auth-buttons">
            <Link to="/login" className="login-btn">Login</Link>
            <Link to="/register" className="register-btn">Register</Link>
          </div>
        </div>
      </nav> */}

      {/* Hero Section */}
      <main className="hero-section">
        <div className="hero-content glass-card">
          <h1>Streamline School Fee Management</h1>
          <p>An intuitive SaaS solution for schools and parents to manage fee payments efficiently</p>
          <div className="cta-buttons">
            <Link to="/register" className="cta-primary">Get Started</Link>
            <Link to="/features" className="cta-secondary">Learn More</Link>
          </div>
        </div>
      </main>

      {/* Bottom Bar */}
      <footer className="glass-footer">
        <div className="footer-content">
          <div className="footer-links">
            <Link to="/privacy" className="footer-link">Privacy Policy</Link>
            <Link to="/terms" className="footer-link">Terms of Service</Link>
            <Link to="/contact" className="footer-link">Contact Us</Link>
          </div>
          <div className="copyright">
            © {new Date().getFullYear()} School Fee Portal. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Home;