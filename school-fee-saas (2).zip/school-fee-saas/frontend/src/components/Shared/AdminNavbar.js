import { Link, useLocation } from 'react-router-dom';
import './AdminNavbar.css';
import { useEffect, useState } from 'react';
import SchoolLogo from '../../assets/school-logo.png';
import DefaultAvatar from '../../assets/school-logo.png';

const AdminNavbar = () => {
  const location = useLocation();
  const [user, setUser] = useState(null);

  // Initialize user from localStorage
  useEffect(() => {
    const userData = localStorage.getItem('user');
    if (userData) {
      setUser(JSON.parse(userData));
    }
  }, []);

  // Highlight active link
  const isActive = (path) => location.pathname === path;

  // Auto-hide on scroll down functionality
  useEffect(() => {
    let lastScroll = 0;
    const navbar = document.querySelector('.admin-navbar');
    
    const handleScroll = () => {
      const currentScroll = window.pageYOffset;
      if (currentScroll <= 0) {
        navbar.classList.remove('scrolled-down');
        navbar.classList.add('scrolled-up');
      } else if (currentScroll > lastScroll) {
        navbar.classList.remove('scrolled-up');
        navbar.classList.add('scrolled-down');
      } else {
        navbar.classList.remove('scrolled-down');
        navbar.classList.add('scrolled-up');
      }
      lastScroll = currentScroll;
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Logout function
  const handleLogout = () => {
    localStorage.removeItem('user');
    localStorage.removeItem('token');
    window.location.href = '/login';
  };

  return (
    <nav className="admin-navbar scrolled-up">
      <div className="navbar-brand">
        <img 
          src={SchoolLogo}
          alt="School Logo" 
          className="logo"
        />
        <span>Admin Dashboard</span>
      </div>

      <div className="navbar-links">
        <Link 
          to="/admin/dashboard" 
          className={`nav-link ${isActive('/admin/dashboard') ? 'active' : ''}`}
        >
          <i className="fas fa-tachometer-alt"></i> Dashboard
        </Link>
        
        <Link 
          to="/admin/payments" 
          className={`nav-link ${isActive('/admin/payments') ? 'active' : ''}`}
        >
          <i className="fas fa-money-bill-wave"></i> Payments
        </Link>
        
        <Link 
          to="/admin/students" 
          className={`nav-link ${isActive('/admin/students') ? 'active' : ''}`}
        >
          <i className="fas fa-user-graduate"></i> Students
        </Link>
        
        <Link 
          to="/admin/parents" 
          className={`nav-link ${isActive('/admin/parents') ? 'active' : ''}`}
        >
          <i className="fas fa-users"></i> Parents
        </Link>
        
        <Link 
          to="/admin/reports" 
          className={`nav-link ${isActive('/admin/reports') ? 'active' : ''}`}
        >
          <i className="fas fa-chart-bar"></i> Reports
        </Link>
      </div>

      <div className="navbar-user">
        {user && (
          <>
            <div className="user-profile">
              <img 
                src={user.avatar || DefaultAvatar}
                alt="User" 
                className="user-avatar"
              />
              <span>{user.name || 'Admin'}</span>
            </div>
            <button onClick={handleLogout} className="logout-btn">
              <i className="fas fa-sign-out-alt"></i> Logout
            </button>
          </>
        )}
      </div>
    </nav>
  );
};

export default AdminNavbar;