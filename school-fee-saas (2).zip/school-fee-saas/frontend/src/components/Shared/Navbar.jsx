import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './NavBar.css';
import SchoolLogo from '../../assets/school-logo.png';

const Navbar = () => {
  const [isVisible, setIsVisible] = useState(true);
  const [isHovered, setIsHovered] = useState(false);

  useEffect(() => {
    let timeoutId;

    // Hide after 10 seconds if not hovered
    if (!isHovered) {
      timeoutId = setTimeout(() => {
        setIsVisible(false);
      }, 10000);
    }

    // Show when hovered at top of page
    const handleMouseMove = (e) => {
      if (e.clientY < 50) { // Top 50px of screen
        setIsVisible(true);
        setIsHovered(true);
        
        // Hide again after 10 seconds when mouse leaves
        const hideAfterDelay = () => {
          setIsHovered(false);
          setTimeout(() => {
            if (!isHovered) setIsVisible(false);
          }, 10000);
        };
        
        window.addEventListener('mouseleave', hideAfterDelay, { once: true });
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      clearTimeout(timeoutId);
    };
  }, [isHovered]);

  return (
    <div className={`navbar-wrapper ${isVisible ? 'visible' : 'hidden'}`}>
      <nav className="glass-navbar">
        <div className="navbar-brand">
          <img 
           src={SchoolLogo}
                    alt="School Logo" 
                    className="logo"
          />
          <span>School Fee Portal</span>
        </div>
        <div className="navbar-links">
          <Link to="/" className="nav-link">Home</Link>
          <Link to="/features" className="nav-link">Features</Link>
          <Link to="/about" className="nav-link">About</Link>
          <div className="auth-buttons">
            <Link to="/login" className="login-btn">Login</Link>
            <Link to="/register" className="register-btn">Register</Link>
          </div>
        </div>
      </nav>
    </div>
  );
};

export default Navbar;