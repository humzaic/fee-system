import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from './components/Auth/Login';
import Home from './components/Home/Home';
import Register from './components/Auth/Register';
import AdminDashboard from './components/Dashboard/AdminDashboard';
import ParentDashboard from './components/Dashboard/ParentDashboard';
// import Layout from './components/Shared/Layout';

const App = () => (
  <Router>
    <Routes>
    <Route path="/" element={<Home />} />          {/* Home Page */}
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/adminDashboard" element={<AdminDashboard />} />
      <Route path="/parentDashboard" element={<ParentDashboard />} />
      <Route path="/" element={<Navigate to="/login" />} />
    </Routes>
  </Router>
);

export default App;