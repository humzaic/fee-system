import { pool } from '../config/db.js';

class Student {
  /**
   * Create a new student record
   * @param {Object} studentData - Student details
   * @param {string} studentData.admissionNo - Student admission number
   * @param {string} studentData.name - Student full name
   * @param {string} studentData.class - Student class/grade
   * @param {string} studentData.section - Class section
   * @param {number} [studentData.parentId] - Parent user ID (optional)
   * @returns {Promise<number>} - Number of affected rows
   */
  static async create({ admissionNo, name, class: className, section, parentId = null }) {
    try {
      const [result] = await pool.execute(
        `INSERT INTO students 
        (admission_no, name, class, section, parent_id) 
        VALUES (?, ?, ?, ?, ?)`,
        [admissionNo, name, className, section, parentId]
      );
      return result.affectedRows;
    } catch (error) {
      console.error('Student creation error:', error);
      throw new Error('Failed to create student record');
    }
  }

  /**
   * Find student by admission number
   * @param {string} admissionNo - Student admission number
   * @returns {Promise<Object|null>} - Student record or null if not found
   */
  static async findByAdmissionNo(admissionNo) {
    try {
      const [rows] = await pool.execute(
        'SELECT * FROM students WHERE admission_no = ?',
        [admissionNo]
      );
      return rows[0] || null;
    } catch (error) {
      console.error('Student findByAdmissionNo error:', error);
      throw new Error('Failed to retrieve student');
    }
  }

  /**
   * Find students by parent ID
   * @param {number} parentId - Parent user ID
   * @returns {Promise<Array>} - Array of student records
   */
  static async findByParentId(parentId) {
    try {
      const [rows] = await pool.execute(
        'SELECT * FROM students WHERE parent_id = ?',
        [parentId]
      );
      return rows;
    } catch (error) {
      console.error('Student findByParentId error:', error);
      throw new Error('Failed to retrieve students by parent');
    }
  }

  /**
   * Update student information
   * @param {string} admissionNo - Student admission number
   * @param {Object} updates - Fields to update
   * @returns {Promise<number>} - Number of affected rows
   */
  static async update(admissionNo, updates) {
    try {
      const fields = Object.keys(updates);
      const values = Object.values(updates);
      
      const setClause = fields.map(field => `${field} = ?`).join(', ');
      
      const [result] = await pool.execute(
        `UPDATE students SET ${setClause} WHERE admission_no = ?`,
        [...values, admissionNo]
      );
      
      return result.affectedRows;
    } catch (error) {
      console.error('Student update error:', error);
      throw new Error('Failed to update student record');
    }
  }

  /**
   * Get all students with optional filters
   * @param {Object} [filters] - Optional filters
   * @param {string} [filters.class] - Filter by class
   * @param {string} [filters.section] - Filter by section
   * @returns {Promise<Array>} - Array of student records
   */
  static async findAll(filters = {}) {
    try {
      let query = 'SELECT * FROM students';
      const params = [];
      
      if (Object.keys(filters).length > 0) {
        const whereClauses = [];
        
        if (filters.class) {
          whereClauses.push('class = ?');
          params.push(filters.class);
        }
        
        if (filters.section) {
          whereClauses.push('section = ?');
          params.push(filters.section);
        }
        
        if (whereClauses.length > 0) {
          query += ` WHERE ${whereClauses.join(' AND ')}`;
        }
      }
      
      const [rows] = await pool.execute(query, params);
      return rows;
    } catch (error) {
      console.error('Student findAll error:', error);
      throw new Error('Failed to retrieve students');
    }
  }

  /**
   * Link student to parent
   * @param {string} admissionNo - Student admission number
   * @param {number} parentId - Parent user ID
   * @returns {Promise<number>} - Number of affected rows
   */
  static async linkToParent(admissionNo, parentId) {
    try {
      const [result] = await pool.execute(
        'UPDATE students SET parent_id = ? WHERE admission_no = ?',
        [parentId, admissionNo]
      );
      return result.affectedRows;
    } catch (error) {
      console.error('Student linkToParent error:', error);
      throw new Error('Failed to link student to parent');
    }
  }
}

export default Student;