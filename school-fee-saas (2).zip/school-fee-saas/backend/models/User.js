import {pool} from '../config/db.js';

class User {
  static async create({ name, email, password, role, cnicNo }) {
    const [result] = await pool.execute(
      'INSERT INTO users (name, email, password, role, cnic_no) VALUES (?, ?, ?, ?, ?)',
      [name, email, password, role, cnicNo]
    );
    return result.insertId;
  }

  static async findByEmail(email) {
    const [rows] = await pool.execute('SELECT * FROM users WHERE email = ?', [email]);
    return rows[0];
  }

  static async findById(id) {
    const [rows] = await pool.execute('SELECT * FROM users WHERE id = ?', [id]);
    return rows[0];
  }

  static async update(id, updates) {
    const fields = Object.keys(updates);
    const values = Object.values(updates);
    const setClause = fields.map(field => `${field} = ?`).join(', ');
    
    await pool.execute(
      `UPDATE users SET ${setClause} WHERE id = ?`,
      [...values, id]
    );
  }
}

export default User;