// import pool from '../config/db.js';

// class Payment {
//   static async create({ parentId, studentAdmissionNo, amount, method, status = 'pending' }) {
//     const receiptNumber = `REC-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;
//     const [result] = await pool.execute(
//       `INSERT INTO payments 
//       (parent_id, student_admission_no, amount, method, status, receipt_number) 
//       VALUES (?, ?, ?, ?, ?, ?)`,
//       [parentId, studentAdmissionNo, amount, method, status, receiptNumber]
//     );
//     return result.insertId;
//   }

//   static async findById(id) {
//     const [rows] = await pool.execute('SELECT * FROM payments WHERE id = ?', [id]);
//     return rows[0];
//   }

//   static async findByParent(parentId) {
//     const [rows] = await pool.execute(
//       `SELECT p.*, s.name as student_name 
//       FROM payments p
//       JOIN students s ON p.student_admission_no = s.admission_no
//       WHERE p.parent_id = ?`,
//       [parentId]
//     );
//     return rows;
//   }

//   static async findAll() {
//     const [rows] = await pool.execute(
//       `SELECT p.*, u.name as parent_name, s.name as student_name 
//       FROM payments p
//       JOIN users u ON p.parent_id = u.id
//       JOIN students s ON p.student_admission_no = s.admission_no`
//     );
//     return rows;
//   }

//   static async updateStatus(id, status) {
//     await pool.execute(
//       'UPDATE payments SET status = ? WHERE id = ?',
//       [status, id]
//     );
//   }

//   static async getDashboardStats() {
//     const [rows] = await pool.execute(`
//       SELECT 
//         COUNT(*) as total_payments,
//         SUM(amount) as total_amount,
//         SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_payments,
//         COUNT(DISTINCT parent_id) as unique_parents
//       FROM payments
//     `);
//     return rows[0];
//   }
// }

// export default Payment;
// In backend/models/Payment.js
static async getParentPaymentsStats(parentId) {
    try {
      const [rows] = await pool.execute(`
        SELECT 
          SUM(CASE WHEN status = 'paid' THEN amount ELSE 0 END) as totalPaid,
          SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pendingPayments,
          COUNT(*) as totalPayments
        FROM payments
        WHERE parent_id = ?
      `, [parentId]);
      
      return {
        totalPaid: rows[0].totalPaid || 0, // Ensure numeric value
        pendingPayments: rows[0].pendingPayments || 0,
        totalPayments: rows[0].totalPayments || 0
      };
    } catch (error) {
      console.error('Error getting payment stats:', error);
      return {
        totalPaid: 0,
        pendingPayments: 0,
        totalPayments: 0
      };
    }
  }