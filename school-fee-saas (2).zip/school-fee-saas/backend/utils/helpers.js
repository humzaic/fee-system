class ApiResponse {
    static success(res, data, statusCode = 200, message = 'Success') {
      res.status(statusCode).json({
        success: true,
        message,
        data
      });
    }
  
    static error(res, error, statusCode = 500) {
      res.status(statusCode).json({
        success: false,
        message: error
      });
    }
  }
  
  module.exports = ApiResponse;