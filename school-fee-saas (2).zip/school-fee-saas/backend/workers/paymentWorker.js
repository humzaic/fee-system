import queueService from '../services/queueService.js';
import PaymentService from '../services/PaymentService.js';

queueService.consumeQueue(async (paymentData) => {
  try {
    await PaymentService.processPayment(paymentData);
    // Trigger success event
    paymentEvents.emit('paymentProcessed', paymentData);
  } catch (error) {
    console.error('Payment processing failed:', error);
  }
});