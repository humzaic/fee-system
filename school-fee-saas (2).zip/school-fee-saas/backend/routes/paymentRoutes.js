// // // // // import express from 'express';
// // // // // import { protect } from '../middlewares/auth.js';
// // // // // import { 
// // // // //   makePayment, 
// // // // //   getPayments, 
// // // // //   getPaymentDetails 
// // // // // } from '../controllers/paymentController.js';

// // // // // const router = express.Router();

// // // // // router.use(protect);

// // // // // router.post('/', makePayment);
// // // // // router.get('/', getPayments);
// // // // // router.get('/:id', getPaymentDetails);

// // // // // export default router;

// // // // import express from 'express';
// // // // import PaymentService from '../services/paymentService.js';
// // // // import { protect } from '../middlewares/auth.js';

// // // // const router = express.Router();

// // // // router.post('/', protect, async (req, res) => {
// // // //   try {
// // // //     const payment = await PaymentService.makePayment({
// // // //       ...req.body,
// // // //       userId: req.user.id
// // // //     });
// // // //     res.status(201).json(payment);
// // // //   } catch (error) {
// // // //     res.status(400).json({ error: error.message });
// // // //   }
// // // // });

// // // // export default router;
// // // import { pool } from '../config/db.js';

// // // class PaymentService {
// // //   static async makePayment(paymentData) {
// // //     const connection = await pool.getConnection();
// // //     try {
// // //       await connection.beginTransaction();

// // //       // Validate student exists and belongs to parent
// // //       const [student] = await connection.execute(
// // //         'SELECT * FROM students WHERE admission_no = ? AND parent_id = ?',
// // //         [paymentData.studentAdmissionNo, paymentData.userId]
// // //       );
      
// // //       if (!student.length) {
// // //         throw new Error('Invalid student admission number');
// // //       }

// // //       // Generate receipt number
// // //       const receiptNumber = `PAY-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;

// // //       // Insert payment record
// // //       const [result] = await connection.execute(
// // //         `INSERT INTO payments 
// // //         (parent_id, student_admission_no, amount, method, status, receipt_number)
// // //         VALUES (?, ?, ?, ?, ?, ?)`,
// // //         [
// // //           paymentData.userId,
// // //           paymentData.studentAdmissionNo,
// // //           paymentData.amount,
// // //           paymentData.method,
// // //           'pending', // initial status
// // //           receiptNumber
// // //         ]
// // //       );

// // //       await connection.commit();
      
// // //       return {
// // //         id: result.insertId,
// // //         ...paymentData,
// // //         status: 'pending',
// // //         receiptNumber,
// // //         paymentDate: new Date().toISOString()
// // //       };
// // //     } catch (error) {
// // //       await connection.rollback();
// // //       console.error('Payment processing error:', error);
// // //       throw new Error(error.message || 'Payment processing failed');
// // //     } finally {
// // //       connection.release();
// // //     }
// // //   }

// // //   static async getPaymentsByParent(parentId) {
// // //     try {
// // //       const [payments] = await pool.execute(
// // //         `SELECT p.*, s.name as student_name 
// // //         FROM payments p
// // //         JOIN students s ON p.student_admission_no = s.admission_no
// // //         WHERE p.parent_id = ?`,
// // //         [parentId]
// // //       );
// // //       return payments;
// // //     } catch (error) {
// // //       console.error('Error fetching payments:', error);
// // //       throw new Error('Failed to retrieve payments');
// // //     }
// // //   }
// // // }

// // // export default PaymentService;
// // import express from 'express';
// // import PaymentService from '../services/paymentService.js';
// // import { protect } from '../middlewares/auth.js';

// // const router = express.Router();

// // // Create payment
// // router.post('/', protect, async (req, res) => {
// //   try {
// //     const payment = await PaymentService.createPayment(req.body);
// //     res.status(201).json(payment);
// //   } catch (error) {
// //     res.status(400).json({ error: error.message });
// //   }
// // });

// // // Update payment
// // router.put('/:id', protect, async (req, res) => {
// //   try {
// //     const payment = await PaymentService.updatePayment(req.params.id, req.body);
// //     res.json(payment);
// //   } catch (error) {
// //     res.status(400).json({ error: error.message });
// //   }
// // });

// // export default router;
// import express from 'express';
// import {
//   createPayment,
//   getParentPayments,
//   getPaymentStats,
//   updatePaymentStatus
// } from '../controllers/paymentController.js';
// import { authenticate, authorize } from '../middleware/authMiddleware.js';
// import { check } from 'express-validator';

// const router = express.Router();

// router.post('/', 
//   authenticate,
//   authorize('parent'),
//   [
//     check('amount', 'Amount is required and must be positive').isFloat({ min: 0.01 }),
//     check('method', 'Payment method is required').notEmpty(),
//     check('studentAdmissionNo', 'Student admission number is required').notEmpty()
//   ],
//   createPayment
// );

// router.get('/parent/:parentId', 
//   authenticate,
//   authorize('parent', 'admin'),
//   getParentPayments
// );

// router.get('/stats', 
//   authenticate,
//   authorize('admin'),
//   getPaymentStats
// );

// router.put('/:id/status', 
//   authenticate,
//   authorize('admin'),
//   updatePaymentStatus
// );

// export default router;
import express from 'express';
import {
  createPayment,
  getParentPayments,
  getPaymentStats,
  updatePaymentStatus
} from '../controllers/paymentController.js';
import { authenticate, authorize } from '../middleware/authMiddleware.js';
import { check } from 'express-validator';

const router = express.Router();

router.post('/', 
  authenticate,
  authorize('parent'),
  [
    check('amount', 'Amount is required and must be positive').isFloat({ min: 0.01 }),
    check('method', 'Payment method is required').notEmpty(),
    check('studentAdmissionNo', 'Student admission number is required').notEmpty()
  ],
  createPayment
);

router.get('/parent/:parentId', 
  authenticate,
  authorize('parent', 'admin'),
  getParentPayments
);

router.get('/stats', 
  authenticate,
  authorize('admin'),
  getPaymentStats
);

router.put('/:id/status', 
  authenticate,
  authorize('admin'),
  updatePaymentStatus
);

export default router;