// const bcrypt = require('bcryptjs');
// const jwt = require('jsonwebtoken');
// const { User, Parent, Admin } = require('../models');
// const ApiResponse = require('../utils/helpers');

// const registerUser = async (userData) => {
//   const { role, studentName, admissionNo, adminCode, cnicNo, ...userFields } = userData;
  
//   // Check if user already exists
//   const existingUser = await User.findOne({ where: { email: userFields.email } });
//   if (existingUser) {
//     throw new Error('User already exists with this email');
//   }

//   // Hash password
//   const salt = await bcrypt.genSalt(10);
//   userFields.password = await bcrypt.hash(userFields.password, salt);

//   const transaction = await sequelize.transaction();
  
//   try {
//     const user = await User.create(userFields, { transaction });

//     if (role === 'parent') {
//       await Parent.create({
//         userId: user.id,
//         studentName,
//         admissionNo
//       }, { transaction });
//     } else {
//       if (adminCode !== process.env.ADMIN_SECRET_CODE) {
//         throw new Error('Invalid admin security code');
//       }
//       await Admin.create({
//         userId: user.id,
//         adminCode,
//         cnicNo
//       }, { transaction });
//     }

//     await transaction.commit();
//     return user;
//   } catch (error) {
//     await transaction.rollback();
//     throw error;
//   }
// };

// const loginUser = async (credentials) => {
//   const { email, password, role, admissionNo, adminCode } = credentials;
  
//   const user = await User.findOne({ 
//     where: { email, role },
//     include: [role === 'parent' ? Parent : Admin]
//   });

//   if (!user) {
//     throw new Error('Invalid credentials');
//   }

//   // Validate password
//   const isMatch = await bcrypt.compare(password, user.password);
//   if (!isMatch) {
//     throw new Error('Invalid credentials');
//   }

//   // Role-specific validations
//   if (role === 'parent' && user.Parent.admissionNo !== admissionNo) {
//     throw new Error('Invalid admission number');
//   }

//   if (role === 'admin' && user.Admin.adminCode !== adminCode) {
//     throw new Error('Invalid admin code');
//   }

//   // Generate JWT
//   const payload = {
//     user: {
//       id: user.id,
//       role: user.role
//     }
//   };

//   return jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '5h' });
// };

// module.exports = {
//   registerUser,
//   loginUser
// };

const API_URL = 'http://localhost:5000/api/auth';

export const authService = {
  register: async (userData) => {
    const response = await fetch(`${API_URL}/register`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(userData),
    });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Registration failed');
    }
    
    return await response.json();
  },
  
  login: async (credentials) => {
    const response = await fetch(`${API_URL}/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(credentials),
    });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'Login failed');
    }
    
    return await response.json();
  }
};