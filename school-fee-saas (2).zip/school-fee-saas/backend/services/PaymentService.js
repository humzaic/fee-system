// // // // // // // import { pool } from '../config/db.js';

// // // // // // // class PaymentService {
// // // // // // //   static async makePayment(paymentData) {
// // // // // // //     const connection = await pool.getConnection();
// // // // // // //     try {
// // // // // // //       await connection.beginTransaction();

// // // // // // //       // Generate receipt number
// // // // // // //       const receiptNumber = `PAY-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;

// // // // // // //       // Insert payment record
// // // // // // //       const [result] = await connection.execute(
// // // // // // //         `INSERT INTO payments 
// // // // // // //         (parent_id, parent_name, student_admission_no, amount, method, status, receipt_number)
// // // // // // //         VALUES (?, ?, ?, ?, ?, ?, ?)`,
// // // // // // //         [
// // // // // // //           paymentData.userId,
// // // // // // //           paymentData.parentName,
// // // // // // //           paymentData.admissionNo || null,
// // // // // // //           paymentData.amount,
// // // // // // //           paymentData.method,
// // // // // // //           'pending', // initial status
// // // // // // //           receiptNumber
// // // // // // //         ]
// // // // // // //       );

// // // // // // //       await connection.commit();
      
// // // // // // //       return {
// // // // // // //         id: result.insertId,
// // // // // // //         ...paymentData,
// // // // // // //         status: 'pending',
// // // // // // //         receiptNumber,
// // // // // // //         date: new Date().toISOString()
// // // // // // //       };
// // // // // // //     } catch (error) {
// // // // // // //       await connection.rollback();
// // // // // // //       console.error('Payment processing error:', error);
// // // // // // //       throw new Error('Payment processing failed');
// // // // // // //     } finally {
// // // // // // //       connection.release();
// // // // // // //     }
// // // // // // //   }
// // // // // // // }

// // // // // // // export default PaymentService;
// // // // // // import { pool } from '../config/db.js';

// // // // // // class PaymentService {
// // // // // //   static async makePayment(paymentData) {
// // // // // //     const connection = await pool.getConnection();
// // // // // //     try {
// // // // // //       await connection.beginTransaction();

// // // // // //       // Validate student exists and belongs to parent
// // // // // //       const [student] = await connection.execute(
// // // // // //         'SELECT * FROM students WHERE admission_no = ? AND parent_id = ?',
// // // // // //         [paymentData.studentAdmissionNo, paymentData.userId]
// // // // // //       );
      
// // // // // //       if (!student.length) {
// // // // // //         throw new Error('Invalid student admission number');
// // // // // //       }

// // // // // //       // Generate receipt number
// // // // // //       const receiptNumber = `PAY-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;

// // // // // //       // Insert payment record
// // // // // //       const [result] = await connection.execute(
// // // // // //         `INSERT INTO payments 
// // // // // //         (parent_id, student_admission_no, amount, method, status, receipt_number)
// // // // // //         VALUES (?, ?, ?, ?, ?, ?)`,
// // // // // //         [
// // // // // //           paymentData.userId,
// // // // // //           paymentData.studentAdmissionNo,
// // // // // //           paymentData.amount,
// // // // // //           paymentData.method,
// // // // // //           'pending', // initial status
// // // // // //           receiptNumber
// // // // // //         ]
// // // // // //       );

// // // // // //       await connection.commit();
      
// // // // // //       return {
// // // // // //         id: result.insertId,
// // // // // //         ...paymentData,
// // // // // //         status: 'pending',
// // // // // //         receiptNumber,
// // // // // //         paymentDate: new Date().toISOString()
// // // // // //       };
// // // // // //     } catch (error) {
// // // // // //       await connection.rollback();
// // // // // //       console.error('Payment processing error:', error);
// // // // // //       throw new Error(error.message || 'Payment processing failed');
// // // // // //     } finally {
// // // // // //       connection.release();
// // // // // //     }
// // // // // //   }

// // // // // //   static async getPaymentsByParent(parentId) {
// // // // // //     try {
// // // // // //       const [payments] = await pool.execute(
// // // // // //         `SELECT p.*, s.name as student_name 
// // // // // //         FROM payments p
// // // // // //         JOIN students s ON p.student_admission_no = s.admission_no
// // // // // //         WHERE p.parent_id = ?`,
// // // // // //         [parentId]
// // // // // //       );
// // // // // //       return payments;
// // // // // //     } catch (error) {
// // // // // //       console.error('Error fetching payments:', error);
// // // // // //       throw new Error('Failed to retrieve payments');
// // // // // //     }
// // // // // //   }
// // // // // // }

// // // // // // export default PaymentService;
// // // // // import { pool } from '../config/db.js';

// // // // // class PaymentService {
// // // // //   static async createPayment(paymentData) {
// // // // //     const connection = await pool.getConnection();
// // // // //     try {
// // // // //       await connection.beginTransaction();

// // // // //       // Generate receipt number
// // // // //       const receiptNumber = `PAY-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;

// // // // //       const [result] = await connection.execute(
// // // // //         `INSERT INTO payments 
// // // // //         (parent_id, student_admission_no, student_name, amount, method, status, payment_date, receipt_number)
// // // // //         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
// // // // //         [
// // // // //           paymentData.parentId,
// // // // //           paymentData.studentAdmissionNo,
// // // // //           paymentData.studentName,
// // // // //           paymentData.amount,
// // // // //           paymentData.method,
// // // // //           paymentData.status,
// // // // //           paymentData.date,
// // // // //           receiptNumber
// // // // //         ]
// // // // //       );

// // // // //       await connection.commit();

// // // // //       return {
// // // // //         id: result.insertId,
// // // // //         ...paymentData,
// // // // //         receiptNumber
// // // // //       };
// // // // //     } catch (error) {
// // // // //       await connection.rollback();
// // // // //       console.error('Payment creation error:', error);
// // // // //       throw new Error('Failed to create payment');
// // // // //     } finally {
// // // // //       connection.release();
// // // // //     }
// // // // //   }

// // // // //   static async updatePayment(id, paymentData) {
// // // // //     const connection = await pool.getConnection();
// // // // //     try {
// // // // //       await connection.beginTransaction();

// // // // //       await connection.execute(
// // // // //         `UPDATE payments SET
// // // // //         amount = ?,
// // // // //         method = ?,
// // // // //         status = ?,
// // // // //         payment_date = ?
// // // // //         WHERE id = ?`,
// // // // //         [
// // // // //           paymentData.amount,
// // // // //           paymentData.method,
// // // // //           paymentData.status,
// // // // //           paymentData.date,
// // // // //           id
// // // // //         ]
// // // // //       );

// // // // //       await connection.commit();

// // // // //       return { id, ...paymentData };
// // // // //     } catch (error) {
// // // // //       await connection.rollback();
// // // // //       console.error('Payment update error:', error);
// // // // //       throw new Error('Failed to update payment');
// // // // //     } finally {
// // // // //       connection.release();
// // // // //     }
// // // // //   }
// // // // // }

// // // // // export default PaymentService;
// // // // import { pool } from '../config/db.js';

// // // // class PaymentService {
// // // //   static async createPayment(paymentData) {
// // // //     const connection = await pool.getConnection();
// // // //     try {
// // // //       await connection.beginTransaction();

// // // //       // Validate student exists
// // // //       const [student] = await connection.execute(
// // // //         'SELECT name FROM students WHERE admission_no = ?',
// // // //         [paymentData.studentAdmissionNo]
// // // //       );
      
// // // //       if (!student.length) {
// // // //         throw new Error('Student not found');
// // // //       }

// // // //       const receiptNumber = `PAY-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;

// // // //       const [result] = await connection.execute(
// // // //         `INSERT INTO payments 
// // // //         (parent_id, student_admission_no, student_name, amount, method, status, date, receipt_number)
// // // //         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
// // // //         [
// // // //           paymentData.parentId,
// // // //           paymentData.studentAdmissionNo,
// // // //           student[0].name,
// // // //           paymentData.amount,
// // // //           paymentData.method,
// // // //           paymentData.status || 'pending',
// // // //           paymentData.date || new Date(),
// // // //           receiptNumber
// // // //         ]
// // // //       );

// // // //       await connection.commit();

// // // //       return {
// // // //         id: result.insertId,
// // // //         ...paymentData,
// // // //         studentName: student[0].name,
// // // //         receiptNumber,
// // // //         status: paymentData.status || 'pending'
// // // //       };
// // // //     } catch (error) {
// // // //       await connection.rollback();
// // // //       throw error;
// // // //     } finally {
// // // //       connection.release();
// // // //     }
// // // //   }

// // // //   static async getParentPayments(parentId) {
// // // //     try {
// // // //       const [payments] = await pool.execute(
// // // //         `SELECT p.*, s.name as student_name 
// // // //         FROM payments p
// // // //         JOIN students s ON p.student_admission_no = s.admission_no
// // // //         WHERE p.parent_id = ?
// // // //         ORDER BY p.date DESC`,
// // // //         [parentId]
// // // //       );
// // // //       return payments;
// // // //     } catch (error) {
// // // //       throw error;
// // // //     }
// // // //   }

// // // //   static async getPaymentStats() {
// // // //     try {
// // // //       const [stats] = await pool.execute(`
// // // //         SELECT 
// // // //           COUNT(*) as total_payments,
// // // //           SUM(amount) as total_amount,
// // // //           SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_payments,
// // // //           SUM(CASE WHEN status = 'paid' THEN 1 ELSE 0 END) as completed_payments
// // // //         FROM payments
// // // //       `);
// // // //       return stats[0];
// // // //     } catch (error) {
// // // //       throw error;
// // // //     }
// // // //   }
// // // // }

// // // // export default PaymentService;
// // // import { pool } from '../config/db.js';

// // // class PaymentService {
// // //   static async createPayment(paymentData) {
// // //     const connection = await pool.getConnection();
// // //     try {
// // //       await connection.beginTransaction();

// // //       // Validate student exists and belongs to parent
// // //       const [student] = await connection.execute(
// // //         'SELECT name FROM students WHERE admission_no = ? AND parent_id = ?',
// // //         [paymentData.studentAdmissionNo, paymentData.parentId]
// // //       );
      
// // //       if (!student.length) {
// // //         throw new Error('Student not found or does not belong to parent');
// // //       }

// // //       const receiptNumber = `PAY-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;

// // //       const [result] = await connection.execute(
// // //         `INSERT INTO payments 
// // //         (parent_id, student_admission_no, amount, method, status, receipt_number)
// // //         VALUES (?, ?, ?, ?, ?, ?)`,
// // //         [
// // //           paymentData.parentId,
// // //           paymentData.studentAdmissionNo,
// // //           paymentData.amount,
// // //           paymentData.method,
// // //           paymentData.status || 'pending',
// // //           receiptNumber
// // //         ]
// // //       );

// // //       await connection.commit();

// // //       return {
// // //         id: result.insertId,
// // //         ...paymentData,
// // //         studentName: student[0].name,
// // //         receiptNumber,
// // //         status: paymentData.status || 'pending',
// // //         paymentDate: new Date()
// // //       };
// // //     } catch (error) {
// // //       await connection.rollback();
// // //       throw error;
// // //     } finally {
// // //       connection.release();
// // //     }
// // //   }

// // //   static async getParentPayments(parentId) {
// // //     try {
// // //       const [payments] = await pool.execute(
// // //         `SELECT 
// // //           p.id, 
// // //           p.amount, 
// // //           p.method, 
// // //           p.status, 
// // //           p.receipt_number as receiptNumber,
// // //           p.payment_date as date,
// // //           s.name as studentName,
// // //           s.admission_no as studentAdmissionNo
// // //         FROM payments p
// // //         JOIN students s ON p.student_admission_no = s.admission_no
// // //         WHERE p.parent_id = ?
// // //         ORDER BY p.payment_date DESC`,
// // //         [parentId]
// // //       );
// // //       return payments;
// // //     } catch (error) {
// // //       throw error;
// // //     }
// // //   }

// // //   static async getPaymentStats(parentId = null) {
// // //     try {
// // //       let query = `
// // //         SELECT 
// // //           COUNT(*) as totalPayments,
// // //           SUM(amount) as totalAmount,
// // //           SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pendingPayments,
// // //           SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completedPayments
// // //         FROM payments
// // //       `;
// // //       const params = [];

// // //       if (parentId) {
// // //         query += ' WHERE parent_id = ?';
// // //         params.push(parentId);
// // //       }

// // //       const [stats] = await pool.execute(query, params);
// // //       return stats[0] || {
// // //         totalPayments: 0,
// // //         totalAmount: 0,
// // //         pendingPayments: 0,
// // //         completedPayments: 0
// // //       };
// // //     } catch (error) {
// // //       throw error;
// // //     }
// // //   }
// // // }

// // // export default PaymentService;
// // import { pool } from '../config/db.js';

// // class PaymentService {
// //   static async createPayment(paymentData) {
// //     const connection = await pool.getConnection();
// //     try {
// //       await connection.beginTransaction();

// //       // Verify student exists and belongs to parent
// //       const [student] = await connection.execute(
// //         `SELECT s.name FROM students s
// //          JOIN users u ON s.parent_id = u.id
// //          WHERE s.admission_no = ? AND s.parent_id = ?`,
// //         [paymentData.studentAdmissionNo, paymentData.parentId]
// //       );
      
// //       if (!student.length) {
// //         throw new Error('Student not found or does not belong to parent');
// //       }

// //       const receiptNumber = `PAY-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`;

// //       const [result] = await connection.execute(
// //         `INSERT INTO payments 
// //         (parent_id, student_admission_no, amount, method, status, receipt_number)
// //         VALUES (?, ?, ?, ?, ?, ?)`,
// //         [
// //           paymentData.parentId,
// //           paymentData.studentAdmissionNo,
// //           paymentData.amount,
// //           paymentData.method,
// //           paymentData.status || 'pending',
// //           receiptNumber
// //         ]
// //       );

// //       await connection.commit();

// //       return {
// //         id: result.insertId,
// //         ...paymentData,
// //         studentName: student[0].name,
// //         receiptNumber,
// //         status: paymentData.status || 'pending',
// //         date: new Date().toISOString()
// //       };
// //     } catch (error) {
// //       await connection.rollback();
// //       console.error('Payment creation error:', error);
// //       throw error;
// //     } finally {
// //       connection.release();
// //     }
// //   }

// //   static async getParentPayments(parentId) {
// //     const connection = await pool.getConnection();
// //     try {
// //       const [payments] = await connection.execute(
// //         `SELECT 
// //           p.id, p.amount, p.method, p.status, 
// //           p.receipt_number as receiptNumber,
// //           p.payment_date as date,
// //           s.name as studentName,
// //           s.admission_no as studentAdmissionNo
// //         FROM payments p
// //         JOIN students s ON p.student_admission_no = s.admission_no
// //         WHERE p.parent_id = ?
// //         ORDER BY p.payment_date DESC`,
// //         [parentId]
// //       );
// //       return payments;
// //     } catch (error) {
// //       console.error('Error fetching payments:', error);
// //       throw error;
// //     } finally {
// //       connection.release();
// //     }
// //   }

// //   static async getPaymentStats(parentId = null) {
// //     const connection = await pool.getConnection();
// //     try {
// //       let query = `
// //         SELECT 
// //           COUNT(*) as totalPayments,
// //           SUM(amount) as totalAmount,
// //           SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pendingPayments,
// //           SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completedPayments,
// //           COUNT(DISTINCT parent_id) as uniqueParents
// //         FROM payments
// //       `;
// //       const params = [];

// //       if (parentId) {
// //         query += ' WHERE parent_id = ?';
// //         params.push(parentId);
// //       }

// //       const [stats] = await connection.execute(query, params);
// //       return stats[0] || {
// //         totalPayments: 0,
// //         totalAmount: 0,
// //         pendingPayments: 0,
// //         completedPayments: 0,
// //         uniqueParents: 0
// //       };
// //     } catch (error) {
// //       console.error('Error fetching stats:', error);
// //       throw error;
// //     } finally {
// //       connection.release();
// //     }
// //   }
// // }

// // export default PaymentService;
// import { pool } from '../config/db.js';
// import { v4 as uuidv4 } from 'uuid';
// import { Queue } from 'bullmq';

// // Message queue for async processing
// const paymentQueue = new Queue('payments', {
//   connection: {
//     host: process.env.REDIS_HOST,
//     port: process.env.REDIS_PORT
//   }
// });

// class PaymentService {
//   constructor() {
//     this.pendingTransactions = new Map();
//   }

//   async initiatePayment(parentId, paymentData) {
//     const connection = await pool.getConnection();
//     try {
//       await connection.beginTransaction();

//       // Check student balance with locking
//       const [student] = await connection.query(
//         `SELECT current_balance 
//          FROM students 
//          WHERE admission_no = ? 
//          FOR UPDATE`,
//         [paymentData.studentAdmissionNo]
//       );

//       // Concurrent balance check
//       if (student[0].current_balance < paymentData.amount) {
//         throw new Error('Insufficient balance');
//       }

//       // Create transaction with idempotency key
//       const idempotencyKey = uuidv4();
//       const [result] = await connection.query(
//         `INSERT INTO transactions 
//         (parent_id, student_admission_no, amount, method, status, idempotency_key)
//         VALUES (?, ?, ?, ?, 'pending', ?)`,
//         [
//           parentId,
//           paymentData.studentAdmissionNo,
//           paymentData.amount,
//           paymentData.method,
//           idempotencyKey
//         ]
//       );

//       // Add to processing queue
//       await paymentQueue.add('process-payment', {
//         transactionId: result.insertId,
//         idempotencyKey
//       });

//       await connection.commit();
//       return { id: result.insertId, status: 'processing' };
//     } catch (error) {
//       await connection.rollback();
//       throw error;
//     } finally {
//       connection.release();
//     }
//   }

//   async processPayment(transactionId) {
//     const connection = await pool.getConnection();
//     try {
//       await connection.beginTransaction();

//       // Get transaction with version check
//       const [txn] = await connection.query(
//         `SELECT * FROM transactions 
//          WHERE id = ? 
//          FOR UPDATE`,
//         [transactionId]
//       );

//       if (!txn.length) throw new Error('Transaction not found');
      
//       // Process payment based on method
//       const processor = this.getPaymentProcessor(txn[0].method);
//       const result = await processor.process(txn[0].amount);

//       // Update transaction status
//       await connection.query(
//         `UPDATE transactions 
//          SET status = 'completed', version = version + 1
//          WHERE id = ?`,
//         [transactionId]
//       );

//       // Update student balance
//       await connection.query(
//         `UPDATE students 
//          SET current_balance = current_balance - ?
//          WHERE admission_no = ?`,
//         [txn[0].amount, txn[0].student_admission_no]
//       );

//       // Insert audit record
//       await connection.query(
//         `INSERT INTO payment_audit 
//         (transaction_id, old_status, new_status)
//         VALUES (?, ?, ?)`,
//         [transactionId, 'pending', 'completed']
//       );

//       await connection.commit();
//       return result;
//     } catch (error) {
//       await connection.rollback();
//       await this.handleFailedPayment(connection, transactionId, error);
//       throw error;
//     } finally {
//       connection.release();
//     }
//   }

//   async handleFailedPayment(connection, transactionId, error) {
//     await connection.query(
//       `UPDATE transactions 
//        SET status = 'failed', version = version + 1
//        WHERE id = ?`,
//       [transactionId]
//     );

//     await connection.query(
//       `INSERT INTO payment_audit 
//       (transaction_id, old_status, new_status)
//       VALUES (?, ?, ?)`,
//       [transactionId, 'pending', 'failed']
//     );

//     // Send notification
//     this.sendFailureNotification(transactionId, error.message);
//   }

//   getPaymentProcessor(method) {
//     switch (method) {
//       case 'credit_card':
//         return new CreditCardProcessor();
//       case 'bank_transfer':
//         return new BankTransferProcessor();
//       case 'cash':
//         return new CashProcessor();
//       default:
//         throw new Error('Invalid payment method');
//     }
//   }

//   sendFailureNotification(transactionId, reason) {
//     // Implementation for sending notifications
//   }
// }

// // Strategy Pattern Implementation
// class PaymentProcessor {
//   async process(amount) {
//     throw new Error('Not implemented');
//   }
// }

// class CreditCardProcessor extends PaymentProcessor {
//   async process(amount) {
//     // Integration with payment gateway
//     return { status: 'completed' };
//   }
// }

// class BankTransferProcessor extends PaymentProcessor {
//   async process(amount) {
//     // Bank transfer logic
//     return { status: 'pending' };
//   }
// }

// class CashProcessor extends PaymentProcessor {
//   async process(amount) {
//     // Cash payment handling
//     return { status: 'completed' };
//   }
// }

// export default new PaymentService();
import { pool } from '../config/db.js';
import { Queue } from 'bullmq';

class PaymentService {
  constructor() {
    this.paymentQueue = new Queue('payments', {
      connection: {
        host: process.env.REDIS_HOST,
        port: process.env.REDIS_PORT
      }
    });
  }

  async initiatePayment(paymentData) {
    const connection = await pool.getConnection();
    try {
      await connection.beginTransaction();

      // Check student balance with locking
      const [student] = await connection.query(
        `SELECT current_balance 
         FROM students 
         WHERE admission_no = ? 
         FOR UPDATE`,
        [paymentData.studentAdmissionNo]
      );

      if (student[0].current_balance < paymentData.amount) {
        throw new Error('Insufficient balance');
      }

      // Create transaction
      const [result] = await connection.query(
        `INSERT INTO transactions 
        (parent_id, student_admission_no, amount, method, status) 
        VALUES (?, ?, ?, ?, 'pending')`,
        [paymentData.parentId, paymentData.studentAdmissionNo, 
         paymentData.amount, paymentData.method]
      );

      // Add to processing queue
      await this.paymentQueue.add('process', {
        transactionId: result.insertId,
        ...paymentData
      });

      await connection.commit();
      return result.insertId;

    } catch (error) {
      await connection.rollback();
      throw error;
    } finally {
      connection.release();
    }
  }
}

export default new PaymentService();