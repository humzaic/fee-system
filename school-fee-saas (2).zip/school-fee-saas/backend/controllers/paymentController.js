// // import Payment from '../models/payment.js';
// // import { validationResult } from 'express-validator';

// // export const createPayment = async (req, res) => {
// //   try {
// //     const errors = validationResult(req);
// //     if (!errors.isEmpty()) {
// //       return res.status(400).json({ errors: errors.array() });
// //     }

// //     const { parentId, studentAdmissionNo, amount, method, status } = req.body;
// //     const payment = await Payment.create({
// //       parentId,
// //       studentAdmissionNo,
// //       amount,
// //       method,
// //       status
// //     });
    
// //     res.status(201).json(payment);
// //   } catch (error) {
// //     console.error('Payment creation error:', error);
// //     res.status(500).json({ message: 'Server error during payment creation' });
// //   }
// // };

// // export const getParentPayments = async (req, res) => {
// //   try {
// //     const { parentId } = req.params;
// //     const payments = await Payment.findByParent(parentId);
// //     res.json(payments);
// //   } catch (error) {
// //     console.error('Error fetching parent payments:', error);
// //     res.status(500).json({ message: 'Server error fetching payments' });
// //   }
// // };

// // export const getPaymentStats = async (req, res) => {
// //   try {
// //     const stats = await Payment.getDashboardStats();
// //     res.json(stats);
// //   } catch (error) {
// //     console.error('Error fetching payment stats:', error);
// //     res.status(500).json({ message: 'Server error fetching stats' });
// //   }
// // };

// // export const updatePaymentStatus = async (req, res) => {
// //   try {
// //     const { id } = req.params;
// //     const { status } = req.body;
    
// //     if (!['pending', 'paid', 'failed'].includes(status)) {
// //       return res.status(400).json({ message: 'Invalid status value' });
// //     }
    
// //     const payment = await Payment.updateStatus(id, status);
// //     res.json(payment);
// //   } catch (error) {
// //     console.error('Error updating payment status:', error);
// //     res.status(500).json({ message: 'Server error updating status' });
// //   }
// // };
// import PaymentService from '../services/paymentService.js';

// export const createPayment = async (req, res) => {
//   try {
//     const payment = await PaymentService.createPayment({
//       ...req.body,
//       parentId: req.user.id
//     });
//     res.status(201).json(payment);
//   } catch (error) {
//     res.status(400).json({ error: error.message });
//   }
// };

// export const getParentPayments = async (req, res) => {
//   try {
//     const payments = await PaymentService.getParentPayments(req.params.parentId);
//     res.json(payments);
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// };

// export const getPaymentStats = async (req, res) => {
//   try {
//     const parentId = req.user.role === 'parent' ? req.user.id : null;
//     const stats = await PaymentService.getPaymentStats(parentId);
//     res.json(stats);
//   } catch (error) {
//     res.status(500).json({ error: error.message });
//   }
// };
import PaymentService from '../services/PaymentService.js';
import { validationResult } from 'express-validator';

export const createPayment = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  try {
    const result = await PaymentService.initiatePayment(
      req.user.id,
      req.body
    );
    res.status(202).json(result);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};

export const getPaymentStatus = async (req, res) => {
  try {
    const [payment] = await pool.query(
      `SELECT * FROM transactions 
       WHERE id = ? AND parent_id = ?`,
      [req.params.id, req.user.id]
    );
    
    if (!payment.length) {
      return res.status(404).json({ error: 'Payment not found' });
    }
    
    res.json(payment[0]);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const getPaymentHistory = async (req, res) => {
  try {
    const [payments] = await pool.query(
      `SELECT t.*, s.name AS student_name 
       FROM transactions t
       JOIN students s ON t.student_admission_no = s.admission_no
       WHERE t.parent_id = ?
       ORDER BY t.transaction_date DESC`,
      [req.user.id]
    );
    
    res.json(payments);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};