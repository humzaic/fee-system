import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import User from '../models/User.js';
import Student from '../models/Student.js';
import config from '../config/env.js';

const generateToken = (user) => {
  return jwt.sign(
    { id: user.id, role: user.role, email: user.email },
    config.JWT_SECRET,
    { expiresIn: config.JWT_EXPIRES_IN }
  );
};

export const register = async (req, res, next) => {
  try {
    const { name, email, password, role, studentName, admissionNo, adminCode, cnicNo } = req.body;

    // Check if user exists
    const existingUser = await User.findByEmail(email);
    if (existingUser) {
      return res.status(400).json({ message: 'Email already in use' });
    }

    // Validate admin code if registering as admin
    if (role === 'admin') {
      const [rows] = await pool.execute(
        'SELECT * FROM admin_codes WHERE code = ? AND is_used = FALSE',
        [adminCode]
      );
      if (rows.length === 0) {
        return res.status(400).json({ message: 'Invalid or used admin code' });
      }
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create user
    const userId = await User.create({
      name,
      email,
      password: hashedPassword,
      role,
      cnicNo
    });

    // If parent, create student record
    if (role === 'parent') {
      await Student.create({
        admissionNo,
        name: studentName,
        class: 'N/A',
        section: 'N/A',
        parentId: userId
      });
    }

    // Mark admin code as used
    if (role === 'admin') {
      await pool.execute(
        'UPDATE admin_codes SET is_used = TRUE WHERE code = ?',
        [adminCode]
      );
    }

    // Generate token
    const token = generateToken({ id: userId, role, email });

    res.status(201).json({
      success: true,
      token,
      user: {
        id: userId,
        name,
        email,
        role,
        ...(role === 'parent' && { admissionNo })
      }
    });
  } catch (error) {
    next(error);
  }
};

export const login = async (req, res, next) => {
  try {
    const { email, password, role, admissionNo, adminCode } = req.body;

    // Find user
    const user = await User.findByEmail(email);
    if (!user || user.role !== role) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    // Validate password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    // Additional validations based on role
    if (role === 'parent') {
      const student = await Student.findByAdmissionNo(admissionNo);
      if (!student || student.parent_id !== user.id) {
        return res.status(401).json({ message: 'Invalid student admission number' });
      }
    } else if (role === 'admin') {
      const [rows] = await pool.execute(
        'SELECT * FROM admin_codes WHERE code = ?',
        [adminCode]
      );
      if (rows.length === 0) {
        return res.status(401).json({ message: 'Invalid admin code' });
      }
    }

    // Generate token
    const token = generateToken(user);

    res.json({
      success: true,
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        ...(role === 'parent' && { admissionNo })
      }
    });
  } catch (error) {
    next(error);
  }
}; //authcontroller.js