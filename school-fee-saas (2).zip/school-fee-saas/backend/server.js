import dotenv from 'dotenv';
dotenv.config();

import express from 'express';
import cors from 'cors';
import { pool } from './config/db.js';  // Named import
import authRoutes from './routes/authRoutes.js';

const app = express();

// Middlewares
app.use(cors());
app.use(express.json());

// Database Connection Test
pool.getConnection()
  .then(conn => {
    console.log('✅ Database Connected!');
    conn.release();
  })
  .catch(err => console.error('❌ Database Error:', err));

// Routes
app.use('/api/auth', authRoutes);

// Test Route
app.get('/', (req, res) => {
  res.send('🚀 School Fee Portal Backend is Running!');
});

// Error Handling
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ success: false, message: 'Internal Server Error' });
});

// Server Start
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🔊 Server running on port ${PORT}`);
});